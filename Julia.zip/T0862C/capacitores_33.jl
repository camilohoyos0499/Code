using JuMP, AmplNLWriter, Bonmin_jll
m = Model(() -> AmplNLWriter.Optimizer(Bonmin_jll.amplexe))

# Parameters
Vnom = 12.66
Barra_SE = 1
Kc = 168           # Cost of kW/h $US
Cinst = 1600        # Installation cost of a capacitive bank $US
Cunit = 25         # Unit cost in each bar
Nmax_sistema = 3    # Maximum number of capacitors in the system
Nmax_unit = 5       # Maximum number of units in the bars           
Qbase = 50         # Base power of capacitive units



# Sets
Ob = [(1),(2),(3),(4),(5),(6),(7),(8),(9),(10),(11),(12),(13),(14),(15),(16),
      (17),(18),(19),(20),(21),(22),(23),(24),(25),(26),(27),(28),(29),(30),
      (31),(32),(33)]

Ol = [(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(7,8),(8,9),(9,10),(10,11),(11,12),
      (12,13),(13,14),(14,15),(15,16),(16,17),(17,18),(2,19),(19,20),(20,21),
      (21,22),(3,23),(23,24),(24,25),(6,26),(26,27),(27,28),(28,29),(29,30),
      (30,31),(31,32),(32,33)]


# Data
PD = Dict(1 => 0, 2 => 100, 3 => 90, 4 => 120, 5 => 60, 6 => 60, 7 => 200, 8 => 200,
          9 => 60, 10 => 60, 11 => 45, 12 => 60, 13 => 60, 14 => 120, 15 => 60, 
          16 => 60, 17 => 60, 18 => 90, 19 => 90, 20 => 90, 21 => 90, 22 => 90, 
          23 => 90, 24 => 420, 25 => 420, 26 => 60, 27 => 60, 28 => 60, 29 => 120,
          30 => 200, 31 => 150, 32 => 210, 33 => 60)
          
QD = Dict(1 => 0, 2 => 60, 3 => 40, 4 => 80, 5 => 30, 6 => 20, 7 => 100, 8 => 100,
          9 => 20, 10 => 20, 11 => 30, 12 => 35, 13 => 35, 14 => 80, 15 => 10,
          16 => 20, 17 => 20, 18 => 40, 19 => 40, 20 => 40, 21 => 40, 22 => 40,
          23 => 50, 24 => 200, 25 => 200, 26 => 25, 27 => 25, 28 => 20, 29 => 70, 
          30 => 600, 31 => 70, 32 => 100, 33 => 40)
          
QC = Dict(1 => 0, 2 => 0, 3 => 0, 4 => 0, 5 => 0, 6 => 0, 7 => 0, 8 => 0, 9 => 0,
          10 => 0, 11 => 0, 12 => 0, 13 => 0, 14 => 0, 15 => 0, 16 => 0, 17 => 0,
          18 => 0, 19 => 0, 20 => 0, 21 => 0, 22 => 0, 23 => 0, 24 => 0, 25 => 0, 
          26 => 0, 27 => 0, 28 => 0, 29 => 0, 30 => 0, 31 => 0, 32 => 0, 33 => 0)
          
R = Dict((1,2) => 0.09220, (2,3) => 0.49300, (3,4) => 0.36600, (4,5) => 0.38110, 
         (5,6) => 0.81900, (6,7) => 0.18720, (7,8) => 0.71140, (8,9) => 1.03000,
         (9,10) => 1.04400, (10,11) => 0.19660, (11,12) => 0.37440, (12,13) => 1.46800,
         (13,14) => 0.54160, (14,15) => 0.59100, (15,16) => 0.74630, (16,17) => 1.28900,
         (17,18) => 0.73200, (2,19) => 0.16400, (19,20) => 1.50420, (20,21) => 0.40950,
         (21,22) => 0.70890, (3,23) => 0.45120, (23,24) => 0.89800, (24,25) => 0.89600,
         (6,26) => 0.20300, (26,27) => 0.28420, (27,28) => 1.05900, (28,29) => 0.80420, 
         (29,30) => 0.50750, (30,31) => 0.97440, (31,32) => 0.31050, (32,33) => 0.34100)
         
X = Dict((1,2) => 0.04700, (2,3) => 0.25110, (3,4) => 0.18640, (4,5) => 0.19410,
         (5,6) => 0.70700, (6,7) => 0.61880, (7,8) => 0.23510, (8,9) => 0.74000, 
         (9,10) => 0.74000, (10,11) => 0.06500, (11,12) => 0.12380, (12,13) => 1.15500,
         (13,14) => 0.71290, (14,15) => 0.52600, (15,16) => 0.54500, (16,17) => 1.72100,
         (17,18) => 0.57400, (2,19) => 0.15650, (19,20) => 1.35540, (20,21) => 0.47840,
         (21,22) => 0.93730, (3,23) => 0.30830, (23,24) => 0.70910, (24,25) => 0.70110,
         (6,26) => 0.10340, (26,27) => 0.14470, (27,28) => 0.93370, (28,29) => 0.70060,
         (29,30) => 0.25850, (30,31) => 0.96300, (31,32) => 0.36190, (32,33) => 0.53020)
         
Imax = Dict(l=>1000 for l in Ol)


# Update parameters
for l in Ol
    R[l] /= 1000 
    X[l] /= 1000
end


Vmax = Vnom # Max voltage 
Vmin = 0.9*Vnom # Min voltage

# Variables 
@variable(m, I[l=Ol], lower_bound=0, upper_bound=Imax[l]) # Current in lines
@variable(m, P[l=Ol]) # Active power in lines
@variable(m, Q[l=Ol]) # Reactive power in lines
@variable(m, V[b=Ob], lower_bound=Vmin, upper_bound=Vmax) # Voltage at buses
@variable(m, Ps[b=Ob],  lower_bound=0) # Active power generated
@variable(m, Qs[b=Ob], lower_bound=0) # Reactive power generated

@variable(m, Qca[b=Ob], lower_bound=0, upper_bound=250)
@variable(m, Wca[b=Ob], Bin)
@variable(m, Nca[b=Ob] >=0, Int)

# # Fix active power 
# for i in filter(x -> x != Barra_SE, Ob)
#     fix(Ps[i], 0) 
# end

# # Fix reactive power
# for i in filter(x -> x != Barra_SE, Ob)  
#     fix(Qs[i], 0)
# end

# # Fix voltaje on SE
# for i in Ob
#     if i == Barra_SE
#         JuMP.fix(V[i], Vnom; force=true)
#     end
# end

non_slack_buses = filter(x -> x != Barra_SE, Ob)


# Objective
@NLobjective(m, Min, (sum( Kc * (R[l]*I[l]^2) for l in Ol) + 0.1 * sum( Cinst * Wca[b] + Cunit * Qca[b] for b in Ob)))

# Active power balance
@NLconstraint(m, [i in Ob], 
    sum(P[l] for l in Ol if l[2] == i) -  
    sum(P[l] + R[l]*I[l]^2 for l in Ol if l[1] == i) + 
    Ps[i] == PD[i])

# Reactive power balance   
@NLconstraint(m, [i in Ob],
    sum(Q[l] for l in Ol if l[2] == i) -
    sum(Q[l] + X[l]*I[l]^2 for l in Ol if l[1] == i) +
    Qs[i] + Qca[i] == QD[i])
    
# Voltage drop in lines
@NLconstraint(m, [l in Ol], 
    V[l[1]]^2 - 2*(R[l]*P[l] + X[l]*Q[l]) - 
    (R[l]^2 + X[l]^2 *I[l]^2) - V[l[2]]^2 == 0)
    
# Apparent power  
@NLconstraint(m, [l in Ol],
    I[l]^2*V[l[2]]^2 == P[l]^2 + Q[l]^2)
 
    
@constraint(m,
    sum(Wca[i] for i in Ob) == Nmax_sistema)
   
@NLconstraint(m, [i in Ob],
    Nca[i] <= Wca[i] * Nmax_unit)

@NLconstraint(m, [i in Ob],
    Qca[i] == Nca[i] * Qbase)

@constraint(m, [i in Ob],
    V[Barra_SE] == Vnom)

@constraint(m, [i in non_slack_buses],
    Ps[i] == 0)

@constraint(m, [i in non_slack_buses],
    Qs[i] == 0)

    


optimize!(m)
println(objective_value(m))
# println(m)
println(JuMP.value.(V))
println(JuMP.value.(Qca))
println(solve_time(m))
